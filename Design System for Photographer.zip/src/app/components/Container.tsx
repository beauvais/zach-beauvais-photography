import { HTMLAttributes, forwardRef } from 'react';

export interface ContainerProps extends HTMLAttributes<HTMLDivElement> {
  size?: 'sm' | 'md' | 'lg' | 'xl' | 'full';
}

export const Container = forwardRef<HTMLDivElement, ContainerProps>(
  ({ className = '', size = 'lg', children, ...props }, ref) => {
    const sizes = {
      sm: 'max-w-2xl',    /* 672px */
      md: 'max-w-4xl',    /* 896px */
      lg: 'max-w-6xl',    /* 1152px */
      xl: 'max-w-7xl',    /* 1280px */
      full: 'max-w-full',
    };
    
    return (
      <div
        ref={ref}
        className={`${sizes[size]} mx-auto px-6 md:px-8 ${className}`}
        {...props}
      >
        {children}
      </div>
    );
  }
);

Container.displayName = 'Container';
