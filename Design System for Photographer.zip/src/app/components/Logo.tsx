interface LogoProps {
  variant?: 'default' | 'stacked' | 'minimal';
  className?: string;
}

export const Logo = ({ variant = 'default', className = '' }: LogoProps) => {
  // Angular Z-inspired mark - represents framing/composition
  const LogoMark = ({ size = 24 }: { size?: number }) => (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Top horizontal */}
      <line 
        x1="6" 
        y1="6" 
        x2="18" 
        y2="6" 
        stroke="currentColor" 
        strokeWidth="1.5"
        strokeLinecap="square"
      />
      {/* Diagonal */}
      <line 
        x1="18" 
        y1="6" 
        x2="6" 
        y2="18" 
        stroke="var(--accent)" 
        strokeWidth="1.5"
        strokeLinecap="square"
      />
      {/* Bottom horizontal */}
      <line 
        x1="6" 
        y1="18" 
        x2="18" 
        y2="18" 
        stroke="currentColor" 
        strokeWidth="1.5"
        strokeLinecap="square"
      />
    </svg>
  );

  if (variant === 'stacked') {
    return (
      <div className={`flex flex-col ${className}`}>
        <div className="flex items-center gap-2">
          <span className="text-2xl font-light leading-none tracking-wide" style={{ fontFamily: 'var(--font-sans)' }}>
            ZACH
          </span>
        </div>
        <div className="flex items-center gap-2 mt-1">
          <LogoMark size={24} />
          <span className="text-2xl font-light leading-none tracking-wide" style={{ fontFamily: 'var(--font-sans)' }}>
            BEAUVAIS
          </span>
        </div>
      </div>
    );
  }

  if (variant === 'minimal') {
    return (
      <div className={`flex items-center gap-2 ${className}`}>
        <LogoMark size={28} />
        <span className="text-lg font-medium tracking-wide" style={{ fontFamily: 'var(--font-sans)' }}>
          ZB
        </span>
      </div>
    );
  }

  // Default horizontal layout
  return (
    <div className={`flex items-center gap-3 ${className}`}>
      <span className="text-xl font-light leading-none tracking-wide" style={{ fontFamily: 'var(--font-sans)' }}>
        ZACH BEAUVAIS
      </span>
      <LogoMark size={24} />
    </div>
  );
};